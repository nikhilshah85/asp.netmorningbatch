﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_RepositoryPattern.Models;
using MVC_RepositoryPattern.Repository;
namespace MVC_RepositoryPattern.Data.InMemoryCollection
{
    //many times i see developers, project impletmet the IRepository interface here, 
    //which looks very logical, but it not a good practice and not recommended
    //dont make it a habit, as you may not get direct access to it
    public class EmployeeInMemory 
    {
        static List<EmployeeModel> eList = new List<EmployeeModel>()
        {
            new EmployeeModel(){ empNo=101, empName="Karan", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
            new EmployeeModel(){ empNo=102, empName="Mohan", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
        };

        //create the methods, needed by the repository

       public List<EmployeeModel> GetEmployeesList()
        {
            return eList;
        }

       public EmployeeModel GetById(int id)
        {
            return eList.Find(e => e.empNo == id);
        }

      public  string AddEmployee(EmployeeModel newEmp)
        {
            //validataions will be done by the repo class
            eList.Add(newEmp);
            return "Employee Added in Collection";
        }

      public  string DeleteEmployee(int id)
        {
            var emp = eList.Find(e => e.empNo == id);
            eList.Remove(emp);
            return "Employee Deleted Successfully from Collection";
        }

      public  string UpdateEmployee(EmployeeModel updates)
        {
            var emp = eList.Find(e => e.empNo == updates.empNo);
            emp.empSalary = updates.empSalary;
            emp.empDesignation = updates.empDesignation;

            return "Employee Details updated in Collection";
        }



      public  double totalSalary()
        {
            return eList.Sum(e => e.empSalary);
        }

      public  int CountTotalEmployees()
        {
            return eList.Count;
        }


    }
}
