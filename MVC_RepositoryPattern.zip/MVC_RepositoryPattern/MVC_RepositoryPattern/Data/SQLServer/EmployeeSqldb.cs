﻿using System;
using System.Collections.Generic;

namespace MVC_RepositoryPattern.Data.SQlServer
{
    public partial class EmployeeSqldb
    {
        public int EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeDesignation { get; set; }
        public int? EmployeeSalary { get; set; }
        public bool? EmpIspermenant { get; set; }
    }
}
