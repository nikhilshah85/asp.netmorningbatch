﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MVC_RepositoryPattern.Data.SQlServer
{
    public partial class MVC_repositoryContext : DbContext
    {
        public MVC_repositoryContext()
        {
        }

        public MVC_repositoryContext(DbContextOptions<MVC_repositoryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<EmployeeSqldb> EmployeeSqldb { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=DESKTOP-NUK26IL\\MUMBAISERVER;database=MVC_repository; integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeSqldb>(entity =>
            {
                entity.HasKey(e => e.EmployeeNo);

                entity.ToTable("EmployeeSQLDB");

                entity.Property(e => e.EmployeeNo).HasColumnName("employeeNo");

                entity.Property(e => e.EmpIspermenant).HasColumnName("empIspermenant");

                entity.Property(e => e.EmployeeDesignation)
                    .HasColumnName("employeeDesignation")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeName)
                    .HasColumnName("employeeName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeSalary).HasColumnName("employeeSalary");
            });
        }
    }
}
