﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_RepositoryPattern.Models;
using MVC_RepositoryPattern.Data.InMemoryCollection;
namespace MVC_RepositoryPattern.Repository
{
    public class EmployeeRepositoryInMemory : IEmployeeRepository
    {
        EmployeeInMemory emp; //this is createing an obj, BAD, use Di

        public EmployeeRepositoryInMemory(EmployeeInMemory empObj)
        {
            emp = empObj;
        }
        public string AddEmployee(EmployeeModel newEmp)
        {
            //do your validations and exceptions here
            return emp.AddEmployee(newEmp);
        }

        public int CountTotalEmployees()
        {
            return emp.CountTotalEmployees();
        }

        public string DeleteEmployee(int id)
        {
            if(id < 0)
            {
                throw new Exception("Please enter a valid positive ID of employee");
            }
            return emp.DeleteEmployee(id);
        }

        public EmployeeModel GetById(int id)
        {
            return emp.GetById(id);
        }

        public List<EmployeeModel> GetEmployeesList()
        {
            return emp.GetEmployeesList();
        }

        public double totalSalary()
        {
            return emp.totalSalary();
        }

        public string UpdateEmployee(EmployeeModel updates)
        {
            return emp.UpdateEmployee(updates);
        }
    }
}
