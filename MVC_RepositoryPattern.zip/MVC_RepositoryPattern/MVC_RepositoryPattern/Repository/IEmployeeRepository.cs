﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_RepositoryPattern.Models;
namespace MVC_RepositoryPattern.Repository
{
   public interface IEmployeeRepository
    {
        List<EmployeeModel> GetEmployeesList();

        EmployeeModel GetById(int id);

        string AddEmployee(EmployeeModel newEmp);

        string DeleteEmployee(int id);

        string UpdateEmployee(EmployeeModel updates);

        double totalSalary();

        int CountTotalEmployees();

    }
}
