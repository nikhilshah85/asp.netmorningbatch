﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_RepositoryPattern.Data.SQlServer;
using MVC_RepositoryPattern.Models;

namespace MVC_RepositoryPattern.Repository
{
    public class EmployeeRepositorySQLServer : IEmployeeRepository
    {
        MVC_repositoryContext _db;
        public EmployeeRepositorySQLServer(MVC_repositoryContext dbObj)
        {
            _db = dbObj;
        }

        public string AddEmployee(EmployeeModel newEmp)
        {
            EmployeeSqldb newEmpSQL = new EmployeeSqldb();
            newEmpSQL.EmployeeNo = newEmp.empNo;
            newEmpSQL.EmployeeName = newEmp.empName;
            newEmpSQL.EmployeeDesignation = newEmp.empDesignation;
            newEmpSQL.EmployeeSalary =Convert.ToInt32(newEmp.empSalary);
            newEmpSQL.EmpIspermenant = newEmp.empIsPermenant;


            _db.EmployeeSqldb.Add(newEmpSQL);
            _db.SaveChanges();
            return "Employee Added to Database";
        }

        public int CountTotalEmployees()
        {
            return _db.EmployeeSqldb.Count();
        }

        public string DeleteEmployee(int id)
        {
            var emp = (from e in _db.EmployeeSqldb
                       where e.EmployeeNo == id
                       select e).Single();
            _db.EmployeeSqldb.Remove(emp);
            _db.SaveChanges();
            return "Employee Deleted from SQL Server";
        }

        public EmployeeModel GetById(int id)
        {
            var emp = (from e in _db.EmployeeSqldb
                       where e.EmployeeNo == id
                       select e).Single();

            EmployeeModel empModel = new EmployeeModel();
            empModel.empNo = emp.EmployeeNo;
            empModel.empName = emp.EmployeeName;
            empModel.empDesignation = emp.EmployeeDesignation;
            empModel.empSalary = Convert.ToInt32(emp.EmployeeSalary);
            empModel.empIsPermenant = Convert.ToBoolean(emp.EmpIspermenant);
            return empModel;
        }

        public List<EmployeeModel> GetEmployeesList()
        {
            var allEmp = _db.EmployeeSqldb.ToList();
            List<EmployeeModel> empList = new List<EmployeeModel>();
            
            foreach (var emp in allEmp)
            {
                EmployeeModel empModel = new EmployeeModel();
                empModel.empNo = emp.EmployeeNo;
                empModel.empName = emp.EmployeeName;
                empModel.empDesignation = emp.EmployeeDesignation;
                empModel.empSalary = Convert.ToInt32(emp.EmployeeSalary);
                empModel.empIsPermenant = Convert.ToBoolean(emp.EmpIspermenant);
                empList.Add(empModel);
            }
            return empList;
        }

        public double totalSalary()
        {
            var totalSal = (from e in _db.EmployeeSqldb
                            select e.EmployeeSalary).Sum();
            return Convert.ToDouble(totalSal);
        }

        public string UpdateEmployee(EmployeeModel updates)
        {
            throw new NotImplementedException();
        }
    }
}
