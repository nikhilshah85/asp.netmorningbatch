﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_RepositoryPattern.Models;
using MVC_RepositoryPattern.Repository;
namespace MVC_RepositoryPattern.Controllers
{
    //controllers will deal only with the interfaces
    public class EmployeeController : Controller
    {
        IEmployeeRepository _emp;

        public EmployeeController(IEmployeeRepository empObj)
        {
            _emp = empObj;
        }

        public IActionResult Employeelist()
        {
            return View(_emp.GetEmployeesList());
        }
            
        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddEmployee(EmployeeModel model)
        {
            ViewBag.message = _emp.AddEmployee(model);
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}