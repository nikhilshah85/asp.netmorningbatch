﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace shoppinhAPP.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {

        [AllowAnonymous]
        public IActionResult ProductList()
        {
            return View();
        }
        public IActionResult OrderStatus()
        {
            return View();
        }
        public IActionResult Transactions()
        {
            return View();
        }

        public IActionResult Wallet()
        {
            return View();
        }
        public IActionResult Profile()
        {
            return View();
        }
    }
}